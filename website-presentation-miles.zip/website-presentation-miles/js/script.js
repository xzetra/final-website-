const toggleNavColor = ()  =>  {
    const navLinks = document.querySelectorAll('nav li u a');
    navLinks.forEach(link =>  {
        link.addEventListener('mouseover', () =>  {
            link.style.color = '#ff6347';
        });
    });
};

// AI was partially used for the generation of the code within this file.
const updateContent = (sectionId, content) => {
    const section = document.getElementById(SectionId);
    if (section) {
        section.innerHTML = '<p>${content}</p>';
    }
};  

toggleNavColor();


const scrollUp = document.querySelector(".scrollTop");

scrollUp.addEventListener("click", () => {
  document.body.scrollTop = 0;
  document.documentElement.scrollTop = 0;
});


function calculateSettingAsThemeString({ localStorageTheme, systemSettingDark }) {
    if (localStorageTheme !== null) {
      return localStorageTheme;
    }
  
    if (systemSettingDark.matches) {
      return "dark";
    }
  
    return "light";
  }
// AI was partially used for the generation of the code within this file.
  const localStorageTheme = localStorage.getItem("theme");
  const systemSettingDark = window.matchMedia("(prefers-color-scheme: light)");
  
  let currentThemeSetting = calculateSettingAsThemeString({ localStorageTheme, systemSettingDark });


  const button = document.querySelector("[theme-changer]");

button.addEventListener("click", () => {
  const currentTheme = currentThemeSetting === "dark" ? "light" : "dark";


  const newTheme = currentTheme === "dark" ? "Light theme" : "Dark theme";
  button.innerText = newTheme;  


  button.setAttribute("aria-label", newTheme);


  document.querySelector("html").setAttribute("data-theme", currentTheme);


  localStorage.setItem("theme", currentTheme);


  currentThemeSetting = currentTheme;
});

// AI was partially used for the generation of the code within this file.