const musicQuestions = [
    {
        question: "What is the most streamed Spotify song of all time?",
        options: ["The Weeknd - Blinding Lights", "Ed Sheeran - Shape of You", "Lewis Capaldi - Someone You Loved", "Harry Styles - As It Was"],
        answer: "The Weeknd - Blinding Lights"
    },
    {
        question: "Who is referred to as the Queen of Pop?",
        options: ["Madonna", "Rihanna", "Beyonce", "Mariah Carey"],
        answer: "Madonna"
    },
    {
        question: "What genre of music is Taylor Swift primarily known for?",
        options: ["Rap", "Pop", "Hip Hop", "Techno"],
        answer: "Pop"
    }
];
// AI was partially used for the generation of the code within this file.
function quizLoader() {
    const quiz = document.getElementById('quiz');

    musicQuestions.forEach((q, index) => {
        const fieldset = document.createElement('fieldset');
        const legend = document.createElement('legend');
        legend.textContent = q.question;
        fieldset.appendChild(legend);

        q.options.forEach(option => {
            const label = document.createElement('label');
            label.innerHTML = `<input type="radio" name="q${index + 1}" value="${option}"> ${option}`;
            fieldset.appendChild(label);
            fieldset.appendChild(document.createElement('br')); // line break for better readability
        });

        quiz.appendChild(fieldset);
    });
}

function answerCheck(event) {
    event.preventDefault();
    let score = 0;

    musicQuestions.forEach((q, index) => {
        const selectedOption = document.querySelector(`input[name="q${index + 1}"]:checked`);
        if (selectedOption && selectedOption.value === q.answer) {
            score++;
        }
    });

    alert(`You received a score of ${score} out of ${musicQuestions.length}!`);
}

// AI was partially used for the generation of the code within this file.
document.addEventListener('DOMContentLoaded', () => {
    quizLoader();
    document.getElementById('submission').addEventListener('click', answerCheck);
});
