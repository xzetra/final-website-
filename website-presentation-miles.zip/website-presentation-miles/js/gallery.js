const art = document.querySelectorAll('.artwork-style');
const galleryC = document.getElementById('gallery-container');
const containerI = document.getElementById('galleryImg');

// AI was used for some part of the development of this code, mostly code improvements
// Function to open the lightbox
art.forEach(image => {
    image.addEventListener('click', function() {
        galleryC.style.display = 'flex'; // Show the lightbox
        containerI.src = this.src; // Set the lightbox image
    });
});

// Close lightbox when clicking outside the image
galleryC.addEventListener('click', function(event) {
    // Check if the click target is the gallery container itself (and not the image)
    if (event.target === galleryC) {
        galleryC.style.display = 'none'; // Hide the lightbox
    }
});

// Close lightbox when the close button is clicked
exit.addEventListener('click', function() {
    galleryC.style.display = 'none'; // Hide the lightbox
});